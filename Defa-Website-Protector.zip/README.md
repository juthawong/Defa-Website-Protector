# Defa-Website-Protector
Protect Front End HTML Injection and Changing without mutation event. Support all browser

Requirement : Jquery 1.8.1 and upper

The project code make it as simple as possible by detecting change after everything is loaded up not just dom ready

and when html code change. It automatically undo in just 1 second.

Defa Website Protector is simple , easy to use , support most of browser and eat very little memory.

It can save life for user form which hacker can edit the html form to enter an undefined number.However,

This script will automatically undo the change without destroying user experience that occur in Mutation Event.


If you like our project. Don't forget to donate us : http://www.juthawong.com/donate
